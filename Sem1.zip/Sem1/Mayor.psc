Algoritmo Mayor 	
	Definir num1, num2, resultado Como Entero
	Escribir "Ingrese el primero numero"
	Leer num1
	Escribir "Ingrese el segundo numero"
	Leer num2
	Si num1>num2 Entonces
		Mostrar "El mayor es: " num1
	SiNo
		Mostrar "El mayor es el: " num2
	FinSi
FinAlgoritmo
