Algoritmo PromedioNotas
    Definir nota1, nota2, promedio Como Real
    Definir i Como Entero
    i = 1
    Mientras i <> 0 Hacer
        Escribir "Ingresa la primera calificaci�n:"
        Leer nota1
        Escribir "Ingresa la segunda calificaci�n:"
        Leer nota2
        promedio <- (nota1 + nota2) / 2
        Mostrar "El promedio es: " promedio
        Escribir "�Deseas calcular otro promedio? (Presiona 1 para S�, 0 para SALIR):"
        Leer i
    FinMientras
FinAlgoritmo
