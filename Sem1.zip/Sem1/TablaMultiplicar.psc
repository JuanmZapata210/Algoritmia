Algoritmo TablaMultiplicar
    Definir tabla, limite, i, resultado Como Entero
    Escribir "1. �Qu� tabla de multiplicar deseas generar?:"
    Leer tabla
    Escribir "2. �Hasta qu� n�mero quieres que multiplique?:"
    Leer limite
    Escribir "TABLA DEL ", tabla, ":"
    Para i = 1 Hasta limite Con Paso 1 Hacer
        resultado = tabla * i
        Escribir tabla, " x ", i, " = ", resultado
    FinPara
FinAlgoritmo
